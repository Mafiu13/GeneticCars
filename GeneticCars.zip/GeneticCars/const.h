#pragma once
const float SCALE = 50;
const int N = 100;