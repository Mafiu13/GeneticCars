#include "Simulation.h"

int main()
{
	Simulation * s = new Simulation();
	s->createSimulation();
}