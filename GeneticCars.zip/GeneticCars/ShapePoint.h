#pragma once
struct ShapePoint
{
	float x;
	float y;
};
